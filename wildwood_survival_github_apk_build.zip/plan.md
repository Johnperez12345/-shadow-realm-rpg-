# Wildwood Survival — Upgrade Plan

1. [done] Import the Android project (WebView game + Gradle + APK workflow) into the repo.
2. [designed, not yet merged] Replace every emoji with hand-drawn 16x16 pixel-art icons (items, tools, HUD, buttons, clock, notifications).
3. [designed, not yet merged] Opaque notifications: stacked toasts with solid backgrounds and color-coded types (good / warn / bad / info), solid hint and feed backgrounds, centered banner for big events.
4. Five distinct islands on a larger map (232x232): Meadow home isle, Frost isle (snow, cold), Ember isle (ash, lava, obsidian), Jungle isle (coconuts, bananas), Dune isle (cactus fruit), each with its own ground, resources and creatures.
5. Raft crafting for sailing between islands; island name label under the clock; island list on the map screen.
6. Temperature bar (cold on Frost isle, fur coat to resist), new items (fur, coat, obsidian, tropical fruits, treasure caches).
7. Achievements screen and extra quests spanning all islands; save version bump (v5).
