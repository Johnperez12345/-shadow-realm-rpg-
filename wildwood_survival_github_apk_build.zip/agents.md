# AGENTS.md

Wildwood Survival is a top-down pixel-art survival game. The entire game lives in one file, `app/src/main/assets/index.html` (Canvas 2D, vanilla JS, no build step), loaded by an Android WebView wrapper (`app/src/main/java/com/wildwood/survival/MainActivity.java`). `.github/workflows/android-apk.yml` builds the APK.

Conventions: compact one-line-per-function style, sections marked `// ===== NAME =====` (ITEMS, RECIPES, WORLD OBJECTS, STATE, SAVE/LOAD, ACTIONS, UPDATE, RENDER, HUD, MODALS, INPUT, LOOP). Saves go to localStorage under a versioned key; bump the key/version when the world format changes.

Non-obvious: the user wants NO emoji anywhere — use drawn pixel icons (canvas-generated, rendered as `<img>` data URLs) — and notification backgrounds must be fully opaque. See PLAN.md for remaining milestones.
