# Build an APK with GitHub Actions

1. Create a GitHub repository (for example `wildwood-survival`).
2. Upload/extract all files from this ZIP into the repository root. Keep the `.github/workflows/build-apk.yml` file; GitHub needs it to build the APK.
3. Commit the files to the `main` branch.
4. Open the repository on GitHub and select **Actions**.
5. Open **Build Wildwood Survival APK** and wait for the run to finish successfully.
6. Open the completed run and download **wildwood-survival-debug-apk** from **Artifacts**. Extract the downloaded artifact ZIP to get `app-debug.apk`.
7. Transfer `app-debug.apk` to your Android phone and install it. If Android blocks installation, allow your browser/file manager to install unknown apps for this file, only if you trust the APK you built.

Notes:
- Uploading source files alone does not instantly make an APK; the Actions workflow must run successfully.
- This produces a debug APK for testing, not a signed Play Store release.
- The workflow may reveal build errors; open the failed run's log if it fails.
