import os,re,zipfile,shutil
root='/tmp/wildfix'
assets=os.path.join(root,'app/src/main/assets')
icons=os.path.join(assets,'icons'); os.makedirs(icons,exist_ok=True)
# Original vector illustrations: 48x48 pixel-game inventory icons, shaded and outlined.
svg={
'wood':'<path d="M8 15L31 5l10 7-23 11z" fill="#d9a05b" stroke="#50351f" stroke-width="2"/><path d="M8 15v18l10 8V23z" fill="#986235" stroke="#50351f" stroke-width="2"/><path d="M18 23l23-11v18L18 41z" fill="#b87a3e" stroke="#50351f" stroke-width="2"/><path d="M26 19l8-4m-8 10l8-4m-8 10l8-4" stroke="#e5b777" stroke-width="2"/>',
'stone':'<path d="M7 29l5-16 14-7 14 9 2 16-13 10-16-3z" fill="#89949b" stroke="#303c43" stroke-width="2.5"/><path d="M12 15l14-7 7 5-12 7z" fill="#c2cbd0"/><path d="M10 29l9-4 8 5-1 8-12-2z" fill="#6e7a81"/><path d="M29 18l8 1 3 11-10 5-4-6z" fill="#a5afb5"/>',
'fiber':'<path d="M23 42C8 34 7 23 10 13c9 3 15 12 13 29z" fill="#438d3d" stroke="#244f2a" stroke-width="2"/><path d="M24 42C20 24 27 11 41 7c2 16-4 27-17 35z" fill="#77b84b" stroke="#2d6a31" stroke-width="2"/><path d="M23 42C14 25 17 15 22 8c7 13 8 23 1 34z" fill="#9acb57" stroke="#477e31" stroke-width="2"/>',
'coal':'<path d="M8 30L13 13 28 6 40 16 38 34 23 42 10 38z" fill="#333a3e" stroke="#11181c" stroke-width="3"/><path d="M13 15l14-7 5 6-13 9z" fill="#62696c"/><path d="M20 26l13-9 5 5-2 10-13 7z" fill="#22282b"/>',
'iron_ore':'<path d="M7 31L12 14 26 6 40 16 41 32 26 42 11 39z" fill="#7e8589" stroke="#30383c" stroke-width="2.5"/><path d="M12 17l14-9 7 6-13 9z" fill="#bd8b58"/><path d="M20 27l12-7 6 5-2 8-12 6z" fill="#b36d3d"/>',
'iron':'<path d="M12 8h24v5H12zM16 13h16v25H16z" fill="#a9b5bd" stroke="#3b454b" stroke-width="2"/><path d="M19 16h10v19H19z" fill="#d6dfe4"/><path d="M9 38h30v4H9z" fill="#707d85"/>',
'gem':'<path d="M7 17L17 6h15l9 11-16 26z" fill="#64d8e5" stroke="#174c62" stroke-width="2.5"/><path d="M7 17h33L25 43z" fill="#2d91b0"/><path d="M17 6l8 11 7-11z" fill="#a6f7fa"/><path d="M17 6l-1 11 9 26" fill="none" stroke="#bafcff" stroke-width="2"/>',
'leather':'<path d="M13 7l8 3 7-3 8 6-3 26-13 4-12-8z" fill="#a96c43" stroke="#4b2d20" stroke-width="2.5"/><path d="M13 13l8 4 8-4M10 30l11 5 12-4" fill="none" stroke="#d39a66" stroke-width="2"/>',
'herb':'<path d="M24 42V13" stroke="#386d32" stroke-width="3"/><path d="M23 28C6 29 6 15 8 10c12 1 17 8 15 18z" fill="#69ad47" stroke="#285b2d" stroke-width="2"/><path d="M25 23C23 9 35 5 42 7c0 11-7 17-17 16z" fill="#8ccf56" stroke="#3d7935" stroke-width="2"/>',
'seed':'<path d="M24 41V24" stroke="#4c7c32" stroke-width="3"/><path d="M23 30C10 30 9 20 11 16c10 1 14 6 12 14z" fill="#79b94b" stroke="#355f2c" stroke-width="2"/><path d="M25 25C25 12 35 9 40 11c0 10-6 14-15 14z" fill="#9ed65c" stroke="#477d32" stroke-width="2"/><ellipse cx="24" cy="42" rx="9" ry="3" fill="#8c643d"/>',
'sapling':'<path d="M24 43V16" stroke="#6d4a2b" stroke-width="4"/><path d="M24 23L10 15l2-7 13 9 11-11 5 5-16 16z" fill="#377f39" stroke="#20512c" stroke-width="2"/><path d="M24 15L21 5l7 1 3 7" fill="#66a846"/>',
'wheat':'<path d="M24 44V8" stroke="#92713c" stroke-width="3"/><path d="M24 16l-9-6 1 8 8 4m0 1l10-7-1 8-9 4m0 1l-9-5 1 8 8 2m0 1l9-6-1 8-8 2" fill="#e7c15e" stroke="#a37a34" stroke-width="1.5"/>',
'berries':'<path d="M24 15v-7m0 5c-8-7-13-3-14 1 6 4 10 3 14-1z" fill="#579344" stroke="#315b2b" stroke-width="2"/><circle cx="17" cy="25" r="8" fill="#bb3548" stroke="#6d1d2a" stroke-width="2"/><circle cx="30" cy="24" r="8" fill="#d94755" stroke="#6d1d2a" stroke-width="2"/><circle cx="24" cy="35" r="8" fill="#9e253d" stroke="#6d1d2a" stroke-width="2"/><circle cx="14" cy="22" r="2" fill="#ffb0a9"/>',
'apple':'<path d="M24 13c-12-10-23 1-17 18 4 13 12 15 17 9 6 6 14 2 17-12 3-15-7-22-17-15z" fill="#d9433f" stroke="#6f2526" stroke-width="2.5"/><path d="M24 13q-1-8 5-10" stroke="#70462b" stroke-width="3" fill="none"/><path d="M27 8q9-7 13 0-7 7-13 0" fill="#5d9d3e"/><path d="M13 20q-2 8 2 11" stroke="#ff9a7c" stroke-width="2" fill="none"/>',
'mushroom':'<path d="M8 25C8 8 17 5 24 5s16 5 16 20z" fill="#b8794c" stroke="#633c2b" stroke-width="2.5"/><path d="M19 25h10l3 17H16z" fill="#e6d6b7" stroke="#8d7558" stroke-width="2"/><circle cx="17" cy="15" r="2" fill="#eac9a0"/><circle cx="28" cy="11" r="2" fill="#eac9a0"/>',
'raw_meat':'<path d="M9 12q7-8 14 0t14 1l4 9-8 16-15 2-9-13z" fill="#c94d4f" stroke="#772d31" stroke-width="2.5"/><path d="M13 18q7-7 12 1t10-1" stroke="#f18b83" stroke-width="4" fill="none"/><path d="M15 30q9-5 17 1" stroke="#f7b1a1" stroke-width="3" fill="none"/>',
'fish':'<path d="M7 24q13-18 28 0Q21 43 7 24z" fill="#8aa6b4" stroke="#334d59" stroke-width="2.5"/><path d="M33 24l11-9v18z" fill="#688998" stroke="#334d59" stroke-width="2"/><circle cx="14" cy="22" r="2" fill="#202b31"/><path d="M20 15l7 9-7 9" fill="none" stroke="#d6e1e5" stroke-width="2"/>',
'bread':'<path d="M8 20q0-10 10-10h13q10 0 10 10v18H8z" fill="#d9a65c" stroke="#79502d" stroke-width="2.5"/><path d="M15 13l4 5m4-6l4 5m4-4l3 5" stroke="#f3d18b" stroke-width="3"/>',
'flask':'<path d="M18 5h12v7l-3 5v18q0 7-6 7t-6-7V17l-3-5V5z" fill="#a6c5cc" stroke="#3c606b" stroke-width="2.5"/><path d="M16 27h12v8q0 5-6 5t-6-5z" fill="#4d9eb8"/><path d="M18 5h12v4H18z" fill="#d7e8e8"/>',
'bandage':'<path d="M8 18L18 8q6-5 11 0l11 11q5 6 0 11L30 40q-6 5-11 0L8 29q-5-5 0-11z" fill="#e9d7b6" stroke="#7f6b50" stroke-width="2"/><path d="M14 18l16 16" stroke="#c5ae88" stroke-width="2"/><g fill="#987e61"><circle cx="20" cy="20" r="1.5"/><circle cx="25" cy="25" r="1.5"/><circle cx="30" cy="30" r="1.5"/></g>',
'axe':'<path d="M20 18l5 4-12 22-5-3z" fill="#8b5b35" stroke="#4b321f" stroke-width="2"/><path d="M17 7q12-4 24 3l-5 13-14-3z" fill="#9baeb5" stroke="#39484f" stroke-width="2.5"/><path d="M17 7l8 1-4 12-5-1z" fill="#dce4e7"/>',
'pick':'<path d="M20 19l5 3-12 22-5-3z" fill="#8b5b35" stroke="#4b321f" stroke-width="2"/><path d="M5 17Q17 1 38 5l5 5Q25 10 10 23z" fill="#9baeb5" stroke="#39484f" stroke-width="2.5"/><path d="M5 17Q18 3 30 6L10 23z" fill="#dce4e7"/>',
'sword':'<path d="M22 25l4 3-13 16-4-3z" fill="#8b5b35" stroke="#4b321f" stroke-width="2"/><path d="M22 25L34 5l7-2-3 8-12 20z" fill="#b7c7ce" stroke="#3d4a50" stroke-width="2"/><path d="M34 5l7-2-3 8z" fill="#f1f5f6"/><path d="M17 29l7 5" stroke="#d4b176" stroke-width="3"/>',
'hammer':'<path d="M20 18l5 3-12 24-5-3z" fill="#8b5b35" stroke="#4b321f" stroke-width="2"/><path d="M9 7h30v9H9z" fill="#9ca8ad" stroke="#3d474c" stroke-width="2.5"/><path d="M9 7h10v9H9z" fill="#d8e0e2"/>',
'hoe':'<path d="M20 19l5 3-12 23-5-3z" fill="#8b5b35" stroke="#4b321f" stroke-width="2"/><path d="M8 8l26 5-2 7-26-5z" fill="#a8b3b8" stroke="#3d474c" stroke-width="2.5"/>',
'rod':'<path d="M8 42L30 5" stroke="#87562f" stroke-width="3.5"/><path d="M30 5q12-2 10 9" stroke="#c3d0d5" stroke-width="1.5" fill="none"/><path d="M40 14v10" stroke="#c3d0d5" stroke-width="1.5"/><path d="M37 24l3 4 3-4" stroke="#c3d0d5" stroke-width="1.5" fill="none"/>',
'bow':'<path d="M10 5q30 19 0 38" stroke="#a8743d" stroke-width="4" fill="none"/><path d="M10 5l30 19L10 43" stroke="#d4d9d9" stroke-width="1.5" fill="none"/><path d="M19 18l10 12" stroke="#79502d" stroke-width="2"/>',
'armor':'<path d="M12 8l8-4 4 5 4-5 8 4 5 11-7 5-2 17H16l-2-17-7-5z" fill="#8799a1" stroke="#34464e" stroke-width="2.5"/><path d="M20 9l4 5 4-5-2 13h-4z" fill="#d1dadd"/><path d="M16 27h16" stroke="#52666e" stroke-width="2"/>',
'torch':'<path d="M19 18l5 3-7 24-5-2z" fill="#8b5b35" stroke="#4b321f" stroke-width="2"/><path d="M17 17q-8-8 1-15 0 8 5 7 5-7 7 0 1 7-9 12z" fill="#ed7c2f" stroke="#a63f20" stroke-width="2"/><path d="M21 14q-3-5 2-8 0 5 3 6l-3 5z" fill="#ffe08a"/>',
'lantern':'<path d="M15 12q0-7 9-7t9 7v24H15z" fill="#52636a" stroke="#263a40" stroke-width="2.5"/><path d="M19 15h10v16H19z" fill="#f5c45b" stroke="#a9782d" stroke-width="2"/><path d="M18 5q0-4 6-4t6 4" stroke="#aebbc0" stroke-width="2.5" fill="none"/><path d="M20 18h8m-8 4h8m-8 4h8" stroke="#fff0a5" stroke-width="1.5"/>',
'campfire':'<path d="M6 34l36 5M10 39l30-8" stroke="#80502b" stroke-width="5"/><path d="M14 33q-8-11 2-19 0 8 5 8 4-11 9-17 9 13 2 22 5-2 7-7 5 15-8 22z" fill="#e86627" stroke="#9d3e1e" stroke-width="2"/><path d="M22 34q-5-8 2-14 0 6 4 7 3-5 3-7 7 12-4 17z" fill="#ffd66b"/>',
'workbench':'<path d="M6 17h36v7H6z" fill="#c08a4a" stroke="#654326" stroke-width="2"/><path d="M10 24h5v17h-5zm23 0h5v17h-5z" fill="#8a5a31" stroke="#654326" stroke-width="2"/><path d="M12 11h24v6H12z" fill="#986637" stroke="#654326" stroke-width="2"/><path d="M17 8l5-4 4 4" stroke="#b8c2c6" stroke-width="3" fill="none"/>',
'furnace':'<path d="M7 8h34v34H7z" fill="#737a7b" stroke="#343d40" stroke-width="2.5"/><path d="M12 13h24v8H12z" fill="#aab0ad"/><path d="M13 25h22v12H13z" fill="#272e30" stroke="#343d40" stroke-width="2"/><path d="M18 35q-4-6 2-9 0 4 3 3 4-6 5 1 1 5-5 6z" fill="#e9752b"/>',
'chest':'<path d="M7 15h34v25H7z" fill="#986333" stroke="#4d321e" stroke-width="2.5"/><path d="M6 11h36v10H6z" fill="#c28a4d" stroke="#4d321e" stroke-width="2.5"/><path d="M22 20h5v9h-5z" fill="#e7c06b" stroke="#6d4b26" stroke-width="1.5"/><path d="M11 26h5v10h-5zm21 0h5v10h-5z" fill="#754725"/>',
'bed':'<path d="M7 7h34v35H7z" fill="#8a633d" stroke="#4c3525" stroke-width="2.5"/><path d="M11 10h26v10H11z" fill="#e8dfc8"/><path d="M11 20h26v18H11z" fill="#b65c65"/><path d="M11 23h26" stroke="#e18b91" stroke-width="3"/><path d="M12 11h8v7h-8z" fill="#f7f0dd"/>',
'floor':'<path d="M5 14l24-10 14 7-24 11z" fill="#d9a05b" stroke="#5c3b22" stroke-width="2"/><path d="M5 14v22l14 8V22z" fill="#9a6537" stroke="#5c3b22" stroke-width="2"/><path d="M19 22l24-11v22L19 44z" fill="#bb8044" stroke="#5c3b22" stroke-width="2"/><path d="M15 10l14 8m-2-11l14 8M19 30l24-11" stroke="#e6b979" stroke-width="1.5"/>',
'wall':'<path d="M7 9h34v31H7z" fill="#b98147" stroke="#5a3a23" stroke-width="2.5"/><path d="M7 18h34M7 29h34M18 9v9m12 0v11M18 29v11" stroke="#684323" stroke-width="2.5"/><path d="M10 12h6m15 9h7m-26 11h7" stroke="#e0ad6b" stroke-width="2"/>',
'door':'<path d="M11 5h27v39H11z" fill="#a86f3d" stroke="#54351f" stroke-width="2.5"/><path d="M16 10h17v29H16z" fill="#c28a4f" stroke="#684323" stroke-width="2"/><path d="M19 14h11v9H19zm0 13h11v9H19z" fill="#996334"/><circle cx="29" cy="25" r="2" fill="#edcf78"/>',
'fence':'<path d="M7 16h34v5H7zM7 33h34v5H7z" fill="#b98348" stroke="#5b3a22" stroke-width="2"/><path d="M10 7h6v34h-6zM21 7h6v34h-6zM32 7h6v34h-6z" fill="#d3a166" stroke="#684323" stroke-width="2"/>',
'spikes':'<path d="M6 38h36v5H6z" fill="#8b623d" stroke="#4d3422" stroke-width="2"/><path d="M8 38l7-24 7 24zm13 0l7-24 7 24z" fill="#9ba6aa" stroke="#3e494e" stroke-width="2"/><path d="M15 14l0 15m13-15l0 15" stroke="#e0e7e9" stroke-width="2"/>',
}
# Write each icon as a standalone crisp vector image.
for name,body in svg.items():
    doc=f'''<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" shape-rendering="crispEdges"><defs><linearGradient id="shine" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff" stop-opacity=".28"/><stop offset="1" stop-color="#000" stop-opacity=".12"/></linearGradient></defs>{body}<path d="M0 0h48v48H0z" fill="url(#shine)" opacity=".05"/></svg>'''
    open(os.path.join(icons,name+'.svg'),'w').write(doc)
# aliases
aliases={
'wood':'wood','stone':'stone','fiber':'fiber','coal':'coal','iron_ore':'iron_ore','iron':'iron','gem':'gem','leather':'leather','herb':'herb','seed':'seed','sapling':'sapling','wheat':'wheat','berries':'berries','apple':'apple','mushroom':'mushroom','raw_meat':'raw_meat','steak':'raw_meat','fish':'fish','cooked_fish':'fish','bread':'bread','stew':'campfire','flask':'flask','water':'flask','bandage':'bandage','axe_wood':'axe','axe_stone':'axe','axe_iron':'axe','pick_wood':'pick','pick_stone':'pick','pick_iron':'pick','sword_wood':'sword','sword_stone':'sword','sword_iron':'sword','sword_gem':'sword','hammer':'hammer','hoe':'hoe','rod':'rod','bow':'bow','arrow':'pick','armor_leather':'armor','armor_iron':'armor','torch':'torch','lantern':'lantern','campfire':'campfire','workbench':'workbench','furnace':'furnace','chest':'chest','bed':'bed','floor':'floor','wall':'wall','stone_wall':'wall','door':'door','fence':'fence','spikes':'spikes'}
# Add helper for item image and replace slot icon with actual image.
p=os.path.join(assets,'index.html'); s=open(p,encoding='utf-8').read()
# Inject icon helper after ITEMS assigned ids.
needle='for (const k in ITEMS) ITEMS[k].id = k;'
mapjs=','.join(f"'{k}':'{v}'" for k,v in aliases.items())
s=s.replace(needle,needle+f"\nconst ITEM_ICON = {{{mapjs}}};\nconst itemIcon = id => 'icons/'+(ITEM_ICON[id]||'wood')+'.svg';\nconst iconImg = (id,cls='item-image') => `<img class=\"${{cls}}\" src=\"${{itemIcon(id)}}\" alt=\"\" draggable=\"false\">`;\nconst iconCache = {{}};\nfunction drawItemIcon(id,x,y,size){{const src=itemIcon(id);let im=iconCache[src];if(!im){{im=new Image();im.src=src;iconCache[src]=im;}}if(im.complete&&im.naturalWidth){{ctx.imageSmoothingEnabled=false;ctx.drawImage(im,x,y,size,size);}}}}")
# CSS for icon images
s=s.replace('.slot .n{position:absolute;', '.item-image{width:29px;height:29px;object-fit:contain;image-rendering:pixelated;pointer-events:none}.slot .item-image{width:31px;height:31px}.igrid .slot .item-image{width:29px;height:29px}.detail .big .item-image{width:38px;height:38px}.rcp .ri .item-image{width:28px;height:28px}.slot .n{position:absolute;')
# Replace slotHTML item display
s=s.replace("const d=ITEMS[s.id]; inner+=d.i;", "const d=ITEMS[s.id]; inner+=iconImg(s.id);")
# detail and recipe image display
s=s.replace('<span class="big">${d.i}</span>', '<span class="big">${iconImg(s.id)}</span>')
s=s.replace('<span class="ri">${d.i}</span>', '<span class="ri">${iconImg(r.id)}</span>')
# held item render use SVG icon, image cache canvas
s=s.replace("ctx.font='11px '+EMOJI_FONT; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(ITEMS[it.id].i,3,-5); ctx.restore();", "drawItemIcon(it.id,-7,-15,22); ctx.restore();")
# remove emoji from item event messages; use names
s=s.replace("'+'+got+' '+ITEMS[id].i", "'+'+got+' '")
s=s.replace("say(ITEMS[it.id].i+' '+ITEMS[it.id].n)", "say(ITEMS[it.id].n)")
s=s.replace("say('Crafted '+ITEMS[r.id].i+' '+ITEMS[r.id].n", "say('Crafted '+ITEMS[r.id].n")
# HUD controls: use simple typographic icons not colorful emoji
s=s.replace('<b>🍗 <span id="foodTxt">100</span></b>','<b>FOOD <span id="foodTxt">100</span></b>')
s=s.replace('<b>💧 <span id="waterTxt">100</span></b>','<b>WATER <span id="waterTxt">100</span></b>')
s=s.replace('>☀️ Day 1</div>','>DAY 1</div>')
s=s.replace('id="menuBtn">⚙️','id="menuBtn">≡').replace('id="mapBtn">🗺️','id="mapBtn">⌖').replace('id="soundToggle">🔊','id="soundToggle">♪')
s=s.replace('id="craft">🛠️<small>CRAFT','id="craft">⌘<small>CRAFT').replace('id="bag">🎒<small>BAG','id="bag">▤<small>BAG').replace('id="act">✋','id="act">USE')
s=s.replace('id="newBtn">🌲 NEW WORLD','id="newBtn">NEW WORLD').replace('id="helpBtn">❔ HOW TO PLAY','id="helpBtn">HOW TO PLAY')
# Toggle icons text to plain symbol
s=s.replace("$('soundToggle').textContent=soundOn?'🔊':'🔇'", "$('soundToggle').textContent=soundOn?'♪':'×'")
# replace held item emoji float text / eat
s=s.replace("floatText(P.x,P.y-20,ITEMS[it.id].i,'#fff')", "floatText(P.x,P.y-20,ITEMS[it.id].n,'#fff')")
# no emoji on item-specific alert feed: strip emojis from dynamic text only
s=s.replace("'🎒 Inventory full!'", "'Inventory full'")
# Fix CSS typography in icon controls
s=s.replace('#act{right:0;bottom:0;width:78px;height:78px;font-size:32px;', '#act{right:0;bottom:0;width:78px;height:78px;font-size:18px;font-weight:900;letter-spacing:1px;')
open(p,'w',encoding='utf-8').write(s)
# README update
readme=os.path.join(root,'readme.md')
with open(readme,'a',encoding='utf-8') as f:
 f.write('\n\nVisual update: item icons now use locally bundled SVG illustrations instead of emoji glyphs. Icons are stored in `app/src/main/assets/icons/` and work offline in the Android WebView.\n')
# package clean ZIP
out='/mnt/data/wildwood_survival_real_item_icons.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for base,dirs,files in os.walk(root):
  dirs[:]=[d for d in dirs if d not in ['.gradle','build']]
  for fn in files:
   fp=os.path.join(base,fn); rel=os.path.relpath(fp,root)
   z.write(fp,rel)
print(out,os.path.getsize(out),'icons',len(svg))
