# Wildwood Survival

A top-down pixel-art survival game for Android: gather, craft, farm, fish, build and survive the night. The game is a single HTML5 Canvas page running inside an Android WebView.

**Tech:** vanilla JavaScript + Canvas 2D, Web Audio sound effects, Java WebView wrapper, Gradle, GitHub Actions APK build.

**Run locally:** open `app/src/main/assets/index.html` in a browser (WASD/arrows to move, Space/E to act), or open the project in Android Studio (SDK 35) and run `assembleDebug`.

**Roadmap:** multiple themed islands with sailing, emoji replaced by pixel-art icons, opaque notifications, temperature, achievements — see PLAN.md.


Visual update: item icons now use locally bundled SVG illustrations instead of emoji glyphs. Icons are stored in `app/src/main/assets/icons/` and work offline in the Android WebView.
