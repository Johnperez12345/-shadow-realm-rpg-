# Shadow Realm: Survival RPG — Android project

This is an Android Studio project wrapper for the landscape, animation-enhanced 3D survival RPG prototype.

## Build a real APK
1. Open this folder in Android Studio (current stable version).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

Or build from a machine with Android SDK and Gradle installed:
`gradle assembleDebug`

## Important
- This is an Android app project, not a precompiled APK. This environment has no Android SDK, no Gradle executable, and the Game Development Studio CLI is unavailable, so it could not compile or device-test an APK here.
- Internet is required because the game loads Three.js from jsDelivr CDN.
- The app is locked to landscape orientation and uses immersive full-screen mode.
- v2.0: animated goblins (grunt, archer, elite, Chieftain boss), 3-hit combo + dash + spin skill, compact HUD, minimap, stat points, shop/equipment, quest chain, resource nodes, loot drops, and auto-save (localStorage).
- Animation is procedural (no skeletal models) and the build was only syntax/logic smoke-tested with a stubbed renderer, not on a real device.
