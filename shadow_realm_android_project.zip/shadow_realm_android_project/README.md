# Shadow Realm RPG — Shared World Co-op Upgrade

A mobile-first landscape Android WebView RPG. Includes a polished dark-fantasy HUD, animated character/enemy combat, a boss roster, and now **true shared-world online co-op with no server setup required**.

## Build APK with GitHub Actions
1. Upload/extract this project so `app/`, `build.gradle`, `settings.gradle`, and `.github/workflows/android-apk.yml` are at repository root.
2. Open **Actions** and run **Build Android APK** (or push to `main`).
3. Download the `shadow-realm-debug-apk` artifact and extract `app-debug.apk`.

## Shared-world co-op (v3)
No configuration needed — the game connects to a free public MQTT relay (broker.emqx.io, with broker.hivemq.com as fallback).

- **Multiplayer → Create room**: you become the world **HOST** and get a 6-character code (e.g. `DGFYUY`).
- **Friend: Multiplayer → Join room**: enters the code and is **teleported to the host's exact location**.
- **Same world for everyone**: the map (trees, rocks, herbs, camp) is generated from a fixed seed, so every device sees the identical terrain.
- **Shared enemies**: the host simulates all enemies and streams world snapshots ~8×/second. An enemy you see is the same enemy your friend sees — same position, same HP.
- **Shared aggro & combat**: attack an enemy and it fights back — it may target YOU or your friend. Damage, kills, arrows, shaman bolts and boss slams are all synced.
- **Shared loot**: gold/herbs/potions dropped by any kill can be picked up by any party member (first grab wins).
- **Party bonus**: +15% XP while at least one friend is online with you.
- **Quick chat**: one-tap pings (Help!, Boss here!, Over here!…) with speech bubbles above heads.
- **Live party panel**: names, levels, HP, and who is HOST — plus teammates on the minimap.
- **Host migration**: if the host disconnects, another hero automatically takes over the world simulation after a few seconds.

Note: co-op trust is client-side (fine for playing with friends); it is not cheat-resistant like a server-authoritative backend.

## New RPG content in v3
- **New enemy — Goblin Shaman**: purple-robed caster that keeps distance and fires arcane bolts (appears once your kill count grows).
- **Two new weapon tiers**: Dragonfang (+42 atk) and Void Reaver (+64 atk) — buy at the merchant with gold + stone.
- **Two new armor tiers**: Dragonscale (+14 def) and Void Shroud (+20 def) — gold + wood.
- **Day/night cycle**: a full 4-minute cycle; night darkens the sky, strengthens the campfire, and slightly increases enemy spawns.
- **Boss HP banner**: a large health bar appears at the top of the screen while a boss is fighting you (shows "SHARED" in co-op).
- **Hero names**: set your name in the Multiplayer tab; it shows on your HUD and above your head for other players.
- Bug fix: an undefined-variable crash in the enemy aura update (could freeze rendering) was repaired.

## Current features
- Landscape phone controls, joystick, attack combo, dash, spin skill, potion, inventory, quests, crafting and merchant.
- Four boss types: Goblin Chieftain, Ironwood Warden, Hollow Wraith and Ashen Colossus. Bosses unlock progressively as the character levels.
- Dark fantasy UI with SVG icons in the HUD.

Three.js and MQTT.js are loaded from a CDN, so the first launch and co-op require internet access. Single-player works offline after first load and progress saves locally.


## Shared-world co-op update
- Room host sends an immediate authoritative enemy snapshot and current shared loot when a new player joins.
- Joining players spawn beside the host and publish their position immediately.
- A joining player retries the room welcome request once to help recover from delayed public MQTT broker messages.
- Enemy simulation and enemy damage remain host-authoritative; both players must use the same room code and have a working internet connection.


## Forest / backpack update
- Trees and rocks require multiple gathering hits based on their size.
- The multiplayer host handles resource durability and drops; resource-hit and depletion events synchronize to party members.
- Added backpack inventory and field crafting recipes for potions, camp kits, and sharpening.
- Enabled soft shadow rendering and atmospheric forest fog.
- Multiplayer remains relay-based and needs real two-device testing; this is not server-authoritative anti-cheat networking.
