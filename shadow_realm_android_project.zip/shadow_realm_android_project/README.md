# Shadow Realm RPG — Eclipse Online Upgrade (v4.0 "Ironclad")

A mobile-first landscape Android WebView RPG. This release fixes the fatal black-screen bug, makes the game run fully offline, and adds a large batch of gameplay, animation and performance upgrades.

## Build APK with GitHub Actions
1. Upload/extract this project so `app/`, `build.gradle`, `settings.gradle`, and `.github/workflows/android-apk.yml` are at repository root.
2. Open **Actions** and run **Build Android APK** (or push to `main`).
3. Download the `shadow-realm-debug-apk` artifact and extract `app-debug.apk`.

## Online multiplayer setup
The online lobby UI is included, but it does not connect until a Supabase project is configured. In `app/src/main/assets/index.html`, replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_KEY` with your project's Project URL and publishable/anon key. Never use a `service_role` secret in the client. Enable Realtime for the project and make sure public broadcast/presence channels are permitted by your project policies. Rebuild the APK after configuration.

The prototype syncs room membership and player positions. Combat, enemy health, drops, and progression are not yet server-authoritative; this is not cheat-resistant full co-op and should be expanded with a server-authoritative game state before public launch.

## Critical fixes in v4.0
- **BLACK SCREEN FIXED (twice over):**
  1. The old build crashed every frame with `ReferenceError: u is not defined` inside `updateEnemy`, which killed the render loop right after the first enemy spawned — the screen went black and controls appeared dead. Fixed.
  2. Three.js was loaded from a CDN, so any offline/weak-internet launch silently failed. The full Three.js module is now **bundled locally** at `app/src/main/assets/lib/three.module.min.js` — the game needs **zero internet** (except the optional online co-op tab).
- **Joystick fixed & hardened:** pointer capture is wrapped in try/catch, movement is tracked window-wide by pointer ID, and stuck-input is cleared on `pointercancel`, `lostpointercapture` and window blur. Multi-touch (moving while attacking) works reliably.
- **Boss models fixed:** Ironwood Warden, The Hollow Wraith and Ashen Colossus previously rendered as small goblins holding a bow. They now spawn at proper boss scale (1.6x–2.35x) with unique skin/cloth colors, red eyes and horns.
- **Activity recreation hardened:** full `configChanges` set in the manifest so rotation/density/UI-mode changes no longer destroy the WebView; WebView state is saved/restored; immersive sticky mode re-applies on focus; renderer priority policy keeps WebGL alive.
- Added a **loading screen with progress**, an animated boot logo and a **fatal-error screen** with a Try Again button — never a silent black screen again.

## Current features
- Landscape phone controls, analog joystick with smoothed movement, attack combo, dash, spin skill, potion, inventory, quests, crafting and merchant.
- **NEW — Day/night cycle** (~3 min): dusk tinting, starfield, fireflies, and a warm torch light that follows the hero at night.
- **NEW — Goblin Shaman enemy** (Lv.4+): keeps range, casts homing shadow bolts, and blinks away when cornered.
- **NEW — Boss top health bar** with name plate when a world boss is engaged.
- **NEW — Combo/kill-streak system:** chained kills build a visible COMBO counter and grant up to +50% gold.
- **NEW — Dash afterimages:** cyan ghost trail while dashing; dynamic FOV kick on dash and spin skill.
- **NEW — Target indicator ring** under your current target; elite/boss ground auras.
- **NEW — Settings tab:** sound, ambient music, vibration (haptics), screen shake, graphics quality (Auto/Low/Med/High) and camera distance (Close/Normal/Far) — all persisted.
- **NEW — Generative ambient music** (evolving pads + wind) plus battle/hit sound effects; haptic feedback on hits, crits and level-ups.
- **NEW — Adaptive quality:** on Auto, resolution scales up/down live to hold a smooth frame rate on any phone.
- Four boss types: Goblin Chieftain, Ironwood Warden, Hollow Wraith and Ashen Colossus, unlocking progressively by level.
- Dark fantasy UI with SVG icons, press animations, low-HP pulse vignette and level-up flash.
- Auto-save every 6 seconds, on quest completion, and on app pause.

The game runs fully offline. (The optional multiplayer tab still needs Supabase configured + internet.)

## Mobile performance pass
- Local Three.js — no CDN latency or failures.
- Adaptive dynamic resolution targeting 60 FPS.
- Damage-number DOM pool capped, HUD DOM writes cached, battery-friendly auto-pause when hidden.


## Supabase connection
The game client is configured with the Shadow-Realm-RPG project URL and a publishable (client-safe) API key. Never place a service-role/secret key in the Android app. The current co-op code uses Realtime broadcast/presence channels for temporary room sessions; it does not yet persist room/player data in the new SQL tables.


## Co-op profile update
- Settings now include a saved player name and four simple hero color skins.
- Player name tags and selected skin are broadcast to room members along with position.
- Limitation: this update does not yet synchronize enemy health/death, combat, or loot across devices. It is still a movement/appearance co-op prototype, not full shared-world combat.
- The Android APK has not been built or tested as part of this source update.
