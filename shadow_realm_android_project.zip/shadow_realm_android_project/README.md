# Shadow Realm RPG — Eclipse Online Upgrade

A mobile-first landscape Android WebView RPG project. Includes a polished dark-fantasy HUD, animated character/enemy combat, boss roster, terrain/collision stability improvements, and an online-room prototype.

## Build APK with GitHub Actions
1. Upload/extract this project so `app/`, `build.gradle`, `settings.gradle`, and `.github/workflows/android-apk.yml` are at repository root.
2. Open **Actions** and run **Build Android APK** (or push to `main`).
3. Download the `shadow-realm-debug-apk` artifact and extract `app-debug.apk`.

## Online multiplayer setup
The online lobby UI is included, but it does not connect until a Supabase project is configured. In `app/src/main/assets/index.html`, replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_KEY` with your project's Project URL and publishable/anon key. Never use a `service_role` secret in the client. Enable Realtime for the project and make sure public broadcast/presence channels are permitted by your project policies. Rebuild the APK after configuration.

The prototype syncs room membership and player positions. Combat, enemy health, drops, and progression are not yet server-authoritative; this is not cheat-resistant full co-op and should be expanded with a server-authoritative game state before public launch.

## Current features
- Landscape phone controls, joystick, attack combo, dash, spin skill, potion, inventory, quests, crafting and merchant.
- Four boss types: Goblin Chieftain, Ironwood Warden, Hollow Wraith and Ashen Colossus. Bosses unlock progressively as the character levels.
- Improved terrain layer separation and obstacle collision when entities overlap exactly.
- Dark fantasy UI with SVG icons instead of emoji in the HUD.

Three.js is loaded from a CDN, so the first launch and gameplay require internet access.


## Mobile performance pass
- Reduced renderer pixel ratio to 1.0 on mobile to lower GPU load.
- Reduced decorative instanced ground detail from 460 to 260 instances.
- Reduced initial enemy count and active normal-enemy cap to lower CPU work during movement.
- These changes are a performance-oriented prototype pass; test on the target Android phone and rebuild the APK before release.
